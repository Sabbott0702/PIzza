﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    double total, topping, tax;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack)
        {
            if (this.sizeList.SelectedIndex == 0)
            {
                total = 10.50;
                topping = 2.5;
            }
            else if (this.sizeList.SelectedIndex == 1)
            {
                total =  8.00;
                topping =  2.0;
            }
            else if (this.sizeList.SelectedIndex == 2)
            {
                total = 6.50;
                topping = 1.5;
            }
        


                foreach(ListItem item in this.toppingsList.Items)
                {
                    if(item.Selected)
                    {
                        total += topping;
                    }
                }

            tax = (total * 1.07);
            
            this.thanksH2.InnerHtml = "Your order will be $"  + tax;

        }




    }

    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }
}